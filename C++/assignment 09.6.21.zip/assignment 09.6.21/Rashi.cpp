
#include <iostream>
//#include "Vehicle.hpp"
#include "Motorcycle.hpp"
using namespace std;
#include <string>

int main()
{
    //cout << "hello" << endl;
    //return 0;
    Motorcycle m(123, 4000);
    m.print();
}